import globalThis from './globalThis.js';

export default globalThis?.navigator?.userAgent;